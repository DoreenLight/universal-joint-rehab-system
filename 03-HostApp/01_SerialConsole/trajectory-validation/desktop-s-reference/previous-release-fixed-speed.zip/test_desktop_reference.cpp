#include <QtWidgets>
#include <QtCharts>
#include <QSerialPort>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <limits>
// Access only in this test translation unit; production has no test hooks.
#define private public
#include "mainwindow.h"
#include "protocolworker.h"
#undef private
#include "ui_mainwindow.h"
#include "mainwindow.cpp"
#include "build/legacy-reference.inc"

static unsigned checks;
#define CHECK(x) do { ++checks; if (!(x)) qFatal("FAIL line %d: %s", __LINE__, #x); } while (0)
static bool near(qreal a, qreal b, qreal eps=1e-9) { return std::abs(a-b)<=eps; }
static void waitEvents(int ms) {
    QEventLoop loop;
    QTimer::singleShot(ms, &loop, &QEventLoop::quit);
    loop.exec();
}
static void referenceMath() {
    const float nan=std::numeric_limits<float>::quiet_NaN();
    struct Case { float a,b,v,p; int n; };
    const Case cases[]={{-30,30,30,2,5},{-12,23,17,.4f,3},{25,-15,17,0,2},
        {5,5,30,2,5},{5,5,30,0,1},{0,.005f,30,.015f,20},
        {-90,80,5,3,20},{0,45,20,0,1},{-30,30,0,2,0},
        {nan,30,nan,-1,21},{-30,nan,30,nan,5}};
    for (const auto &c:cases) {
        qreal oldT=0,newT=0;
        const auto old=legacyMakeRefTrajectory(c.a,c.b,c.v,c.p,c.n,&oldT);
        const auto now=makeRefTrajectory(c.a,c.b,c.v,c.p,c.n,&newT);
        CHECK(oldT==newT && now.first()==old.first() && now.last()==old.last());
        CHECK(now.size()>=old.size());
        // Every original hold/ramp boundary is retained at exactly the old time.
        int k=0;
        for (const auto &boundary:old) {
            while(k<now.size() && now[k]!=boundary) ++k;
            CHECK(k<now.size());
        }
        const qreal low=qMin(old.first().y(),old[2].y());
        const qreal high=qMax(old.first().y(),old[2].y());
        for(int i=0;i<now.size();++i) {
            CHECK(qIsFinite(now[i].x()) && qIsFinite(now[i].y()));
            CHECK(now[i].y()>=low-1e-12 && now[i].y()<=high+1e-12);
            if(i) CHECK(now[i].x()>=now[i-1].x());
        }
        // Independent per-segment oracle, evaluated at both grid and off-grid times.
        for(int j=1;j<old.size();++j) {
            const auto a=old[j-1],b=old[j];
            if(b.x()<=a.x()) continue;
            qreal previous=a.y();
            for(int s=0;s<=401;++s) {
                const long double u=static_cast<long double>(s)/401;
                const long double f=6*std::pow(u,5)-15*std::pow(u,4)+10*std::pow(u,3);
                const qreal t=a.x()+(b.x()-a.x())*static_cast<qreal>(u);
                const qreal expected=a.y()+(b.y()-a.y())*static_cast<qreal>(f);
                const qreal p=refValueAt(now,t);
                // QLineSeries samples the analytic curve at 200 intervals/ramp.
                CHECK(near(p,expected,qMax(1e-8,std::abs(b.y()-a.y())*2e-5)));
                if(b.y()>a.y()) CHECK(p>=previous-1e-9);
                if(b.y()<a.y()) CHECK(p<=previous+1e-9);
                previous=p;
            }
        }
        CHECK(refValueAt(now,-1)==old.first().y());
        CHECK(refValueAt(now,newT+1)==old.last().y());
    }
    qreal t;
    const auto p=makeRefTrajectory(-30,30,30,2,5,&t);
    CHECK(t==40 && refValueAt(p,2)==-30 && refValueAt(p,4)==30);
    CHECK(refValueAt(p,6)==30 && refValueAt(p,8)==-30);
    CHECK(near(refValueAt(p,2.5),-23.7890625));
    CHECK(near(refValueAt(p,3.5),23.7890625));
    for(double u:{0.,1.}) {
        CHECK(30*u*u*(1-u)*(1-u)==0); // endpoint velocity
        CHECK(60*u*(1-u)*(1-2*u)==0); // endpoint acceleration
    }
    std::printf("PASS analytic samples, range, reverse/zero ramps, fallback semantics and exact legacy timing\n");
}

static void configure(MainWindow &w,const QStringList &m1,const QStringList &m2,int n) {
    for(int i=0;i<4;++i) { w.m1ActEdits[i]->setText(m1[i]); w.m2ActEdits[i]->setText(m2[i]); }
    w.trackerCyclesSpin->setValue(n);
}
static void deliver(ProtocolWorker &receiver,const QMap<uint8_t,float> &values) {
    QByteArray payload; payload.append(char(values.size()));
    for(auto it=values.cbegin();it!=values.cend();++it) {
        payload.append(char(it.key())); uint32_t bits;
        const float value=it.value(); std::memcpy(&bits,&value,4);
        for(unsigned b=0;b<4;++b) payload.append(char((bits>>(8*b))&255));
    }
    const auto frame=receiver.buildFrame(CMD_TELEMETRY,payload);
    CHECK(receiver.parseFrame(reinterpret_cast<const uint8_t*>(frame.constData()),frame.size())==frame.size());
}
static void legend(MainWindow &w,MainWindow::TrackerCtx &c) {
    w.refreshTrackerLegend(c);
    for(auto *marker:c.chart->legend()->markers()) {
        const auto *s=marker->series();
        CHECK(marker->isVisible()==(s==c.refSeries || s==c.histTargetSeries || s==c.histActualSeries));
    }
}
int main(int argc,char **argv) {
    QApplication app(argc,argv);
    const int font=QFontDatabase::addApplicationFont("C:/Windows/Fonts/msyh.ttc");
    CHECK(font>=0);
    app.setFont(QFont(QFontDatabase::applicationFontFamilies(font).first(),9));
    referenceMath();
    MainWindow w;
    ProtocolWorker receiver;
    unsigned sent=0,received=0;
    QObject::connect(&receiver,&ProtocolWorker::rawDataSent,[&](const QByteArray&){++sent;});
    QObject::connect(w.protoWorker,&ProtocolWorker::rawDataSent,[&](const QByteArray&){++sent;});
    QObject::connect(&receiver,&ProtocolWorker::telemetryReceived,&w,[&](const QMap<uint8_t,float>&values) {
        ++received; w.onTelemetryReceived(values);
    });
    w.showRehabPage();
    w.resize(1500,1100); w.show(); app.processEvents();
    CHECK(w.trackerM1.totalT==40 && w.trackerM2.totalT==40);
    CHECK(w.trackerM1.refSeries->points()==w.trackerM1.refTraj);
    CHECK(w.trackerM2.refSeries->points()==w.trackerM2.refTraj);
    CHECK(w.grab().save("preview-before.png"));
    legend(w,w.trackerM1); legend(w,w.trackerM2);
    const auto initial=w.trackerM1.refTraj;
    w.startExperiment(); waitEvents(110);
    CHECK(w.trackerM1.running && w.trackerM2.running);
    CHECK(w.trackerM1.nowT>=.03 && w.trackerM1.nowT<=.5);
    CHECK(std::abs(w.trackerM1.nowT-w.trackerM2.nowT)<=.005);
    CHECK(w.trackerM1.refTraj==initial);
    for(auto *c:{&w.trackerM1,&w.trackerM2}) {
        CHECK(std::abs(c->nowT-c->clock.elapsed()/1000.)<.1);
        CHECK(c->cursorSeries->points().first().x()==c->nowT);
    }
    // Exercise a whole changing telemetry stream through the original parser.
    // Draw deterministic synthetic history; don't wait a real 40-second session.
    w.mTrackerTimer->stop();
    w.m_recording=true;
    w.trackerM1.rawCheck->setChecked(true); w.trackerM2.rawCheck->setChecked(true);
    for(int i=0;i<160;++i) {
        const float a=-25.f+i*.25f,b=17.f-i*.125f;
        const QMap<uint8_t,float> values={{0x01,a+1},{0x02,a},{0x0B,11.f},
            {0x11,b+2},{0x12,b},{0x1D,-12.f},{0x41,2.5f},{0x44,-.75f}};
        w.trackerM1.nowT=w.trackerM2.nowT=i*.1;
        deliver(receiver,values);
        CHECK(w.trackerM1.lastActual==a && w.trackerM2.lastActual==b);
        CHECK(w.trackerM1.lastTarget==a+1 && w.trackerM2.lastTarget==b+2);
        CHECK(w.trackerM1.histActualSeries->points().last()==QPointF(i*.1,a));
        CHECK(w.trackerM2.histActualSeries->points().last()==QPointF(i*.1,b));
        CHECK(w.trackerM1.histTargetSeries->points().last().y()==a+1);
        CHECK(w.trackerM2.histTargetSeries->points().last().y()==b+2);
        CHECK(w.trackerM1.lastRaw==11 && w.trackerM2.lastRaw==-12);
        CHECK(w.m_recordBuffer.last().values==values);
        CHECK(w.trackerM1.refTraj==initial);
    }
    CHECK(w.trackerM1.histActualSeries->count()==160);
    CHECK(w.trackerM2.histActualSeries->count()==160);
    CHECK(w.trackerM1.rawSeries->count()==160 && w.trackerM2.rawSeries->count()==160);
    // Existing invalid feedback filter remains a filter, never a smoothing path.
    const auto actual=w.trackerM1.lastActual;
    const int count=w.trackerM1.histActualSeries->count();
    deliver(receiver,{{0x02,100000.f}});
    CHECK(w.trackerM1.lastActual==actual && w.trackerM1.histActualSeries->count()==count);
    CHECK(w.trackerM1.dropped==1 && w.m_recordBuffer.last().values.value(0x02)==100000.f);
    w.m_recording=false;
    w.trackerM1.running=w.trackerM2.running=false;
    w.updateTrackerViews();
    CHECK(w.grab().save("preview-synthetic-feedback.png"));
    // Restart the actual elapsed clocks and finish both through the real timer.
    configure(w,{"6000","-30","30","0"},{"3000","-15","15","0"},1);
    w.startExperiment(); w.mTrackerTimer->start(); waitEvents(120);
    CHECK(near(w.trackerM1.totalT,.02) && near(w.trackerM2.totalT,.02));
    CHECK(w.trackerM1.finished && w.trackerM2.finished);
    CHECK(!w.trackerM1.running && !w.trackerM2.running);
    CHECK(w.trackerM1.nowT==w.trackerM1.totalT && w.trackerM2.nowT==w.trackerM2.totalT);
    CHECK(w.trackerM1.histActualSeries->count()==0 && w.trackerM2.histActualSeries->count()==0);
    CHECK(w.trackerM1.cursorSeries->points().first().x()==w.trackerM1.totalT);
    legend(w,w.trackerM1); legend(w,w.trackerM2);
    configure(w,{"30","-30","30","2"},{"17","-12","23",".4"},5);
    w.startExperiment();
    CHECK(!w.trackerM1.finished && !w.trackerM2.finished);
    CHECK(w.trackerM1.running && w.trackerM2.running);
    CHECK(w.trackerM1.refTraj==initial && w.trackerM1.totalT==40);
    qreal oldT;
    legacyMakeRefTrajectory(-12,23,17,.4f,5,&oldT);
    CHECK(w.trackerM2.totalT==oldT && w.trackerM1.totalT!=w.trackerM2.totalT);
    CHECK(!w.trackerM1.hasActual && !w.trackerM2.hasActual);
    CHECK(sent==0 && received==161 && !receiver.isOpen() && !w.protoWorker->isOpen());
    legend(w,w.trackerM1); legend(w,w.trackerM2);
    std::printf("PASS %u checks; original desktop UI/parser/clock/state/recording; %u synthetic telemetry frames; zero sends; no open ports\n",checks,received);
}
