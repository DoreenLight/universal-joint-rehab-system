"""Restore the exact tested host snapshot and extract the original timing oracle."""
from pathlib import Path
import hashlib
import json
import zipfile

HERE = Path(__file__).resolve().parent
manifest = json.loads((HERE / 'baseline-sha256.json').read_text(encoding='utf-8'))
build = HERE / 'build'
source = build / 'source'
before = build / 'before'
source.mkdir(parents=True, exist_ok=True)
before.mkdir(parents=True, exist_ok=True)
files = list(manifest['source_sha256'])
with zipfile.ZipFile(HERE / 'desktop-original-source.zip') as old_zip, \
        zipfile.ZipFile(HERE / 'tested-host-source.zip') as new_zip:
    assert set(old_zip.namelist()) == set(new_zip.namelist()) == set(files)
    for name in files:
        old, new = old_zip.read(name), new_zip.read(name)
        assert hashlib.sha256(old).hexdigest() == manifest['source_sha256'][name]
        (before / name).write_bytes(old)
        (source / name).write_bytes(new)
        if name != 'mainwindow.cpp':
            assert old == new, name

old = (before / 'mainwindow.cpp').read_bytes()
new = (source / 'mainwindow.cpp').read_bytes()
old_start = old.index('// 生成 N 周期分段线性三角波：'.encode())
new_start = new.index(b'// Local S reference:')
marker = '// 图例条目固定为三条数据曲线'.encode()
assert old[:old_start] == new[:new_start]
assert old[old.index(marker, old_start):] == new[new.index(marker, new_start):]
first = old.index(b'static QList<QPointF> makeRefTrajectory(')
legacy = old[first:old.index(marker, first)]
(build / 'legacy-reference.inc').write_bytes(
    legacy.replace(b'makeRefTrajectory(', b'legacyMakeRefTrajectory(', 1))
(HERE / 'scope-results.txt').write_text(
    'PASS: only makeRefTrajectory and its adjacent comments differ from the desktop original.\n'
    'PASS: every byte outside that region and all seven other source files are unchanged.\n'
    'PASS: firmware source, timers, protocol, feedback and recording are not part of this patch.\n',
    encoding='utf-8')
print('PASS: source scope and original desktop timing fixture')
