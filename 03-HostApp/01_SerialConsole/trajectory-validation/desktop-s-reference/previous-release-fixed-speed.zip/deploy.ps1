# Explicitly requested desktop update. No build, port, device or flash operations.
$ErrorActionPreference = 'Stop'
$manifest = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'baseline-sha256.json') -Raw | ConvertFrom-Json
$sourceTarget = Join-Path $manifest.source 'mainwindow.cpp'
$exeTarget = $manifest.desktop_exe
$sourceCandidate = Join-Path $PSScriptRoot 'build/source/mainwindow.cpp'
$exeCandidate = Join-Path $PSScriptRoot 'build/validation/Uart_controller.exe'
$oldSource = Join-Path $PSScriptRoot 'build/before/mainwindow.cpp'
$oldExe = Join-Path $PSScriptRoot 'build/rollback/Uart_controller.exe'
function Hash([string]$path) { (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant() }
if ((Hash $exeCandidate) -ne '3392e0d39b9b01c43bced9aa47ba79f76fff7a6829aabf441758186bf86a43d2') { throw 'Executable is not the tested build' }
if ((Hash $sourceCandidate) -ne '2bdf750462fcd9e71bb39a6bca88e6a49c6f28d4d6d1d419456d592404239f2b') { throw 'Source is not the tested version' }
foreach ($entry in $manifest.source_sha256.PSObject.Properties) {
    if ((Hash (Join-Path $manifest.source $entry.Name)) -ne $entry.Value) { throw "Desktop source changed after snapshot: $($entry.Name)" }
}
if ((Hash $exeTarget) -ne $manifest.desktop_exe_sha256) { throw 'Desktop executable changed after snapshot' }
$running = @(Get-Process -Name Uart_controller -ErrorAction SilentlyContinue)
if ($running.Count) { throw 'An application instance is running; do not terminate an experiment automatically' }
if ((Hash $oldExe) -ne $manifest.desktop_exe_sha256) { throw 'Executable rollback backup mismatch' }
if ((Hash $oldSource) -ne $manifest.source_sha256.'mainwindow.cpp') { throw 'Source rollback backup mismatch' }
try {
    Copy-Item -LiteralPath $sourceCandidate -Destination $sourceTarget -Force
    Copy-Item -LiteralPath $exeCandidate -Destination $exeTarget -Force
    if ((Hash $sourceTarget) -ne (Hash $sourceCandidate)) { throw 'Source deployment mismatch' }
    if ((Hash $exeTarget) -ne (Hash $exeCandidate)) { throw 'Executable deployment mismatch' }
} catch {
    Copy-Item -LiteralPath $oldSource -Destination $sourceTarget -Force
    Copy-Item -LiteralPath $oldExe -Destination $exeTarget -Force
    throw
}
[ordered]@{
    updatedUtc = [DateTime]::UtcNow.ToString('o')
    source = $sourceTarget
    sourceSha256 = (Hash $sourceTarget)
    executable = $exeTarget
    executableSha256 = (Hash $exeTarget)
    priorExecutableSha256 = $manifest.desktop_exe_sha256
    shortcutChanged = $false
    flashed = $false
} | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $PSScriptRoot 'deployment-receipt.json') -Encoding utf8
'PASS: desktop source and original shortcut target updated; rollback backups retained; no flash operations'
